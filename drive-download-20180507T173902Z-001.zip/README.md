
# TODO list

- [ ] Show name in the existing edit control. 
- [ ] fix unit tests

- [ ] Add an editable field that displays the city received from the Web API (in the Address object). 
- [ ] Make the new field mandatory
- [ ] Add validation that ensures the city is unique across all cities on the Web API.

- [ ] Add unit tests for the new functionality

